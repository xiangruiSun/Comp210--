package assn01;

public class HelloWorld {
    public static void main(String[] args) {
        String s1 = "Hello";
        int n = 5;
        method1();
        System.out.print(s1);
    }
    public static void method1() {
        char s1 = 'x';
    }
}
