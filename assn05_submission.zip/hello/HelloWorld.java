package hello;

public class HelloWorld {
    public static void main(String[] args) {
        float [] a = new float[10];
        System.out.println(a[9]);
    }
}

//public static void main
//public: method can be accessed from everywhere, it is a public class
//static: associated wth a particular class, not instance of a class
//void: the method does not return anything
//main the name of the method is main
// java looks for main() to execute its code
// line 4 should be identical in all codes
// string[] args: has one parameter and it is an array of strings, named args

