package lec1;

public class Stack2 {

    public static void main (String[] args){
        int n = 0;
        String s1 = "Hello";
        System.out.println(s1.toLowerCase());
        m1();
    }

    public static void m1 (){
        int n1 = 1;
    }
}
