package lec1;

public class Example1 {
    public static void main(String[] args){

        //primitive data types
        byte by = 123;
        short sh = 32767;
        float fl = 9.9f; //note the f behind the number
        double d = 9.9;
        long l = 1234567890;

        //reference data types
        String s = "Hello";
        String[] sA = {"Hi", "Bye"}; // String[] array of strings
        char[] cA = {'a', 'b'};
        float[] fA = {2.5f, 3.2f};
    }
}
